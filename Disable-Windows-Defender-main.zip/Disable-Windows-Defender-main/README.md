# Disable-Windows-Defender
<br>Disable Windows Defender All Version for RedTeaming Operation </br>
<br>Tested On Windows Server 2019 and Windows 10 2004 (12/20/2020)</br>
![Alt Text](https://raw.githubusercontent.com/akizaizinski1311/Disable-Windows-Defender/main/DisableDefender.gif)
